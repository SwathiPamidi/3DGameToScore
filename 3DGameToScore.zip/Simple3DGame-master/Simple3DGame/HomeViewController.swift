//
//  HomeViewController.swift
//  Simple3DGame
//
//  Created by Swathi Pamidi on 6/9/18.
//  Copyright © 2018 Brian Advent. All rights reserved.
//

import UIKit

protocol HomeViewDelegate: class {
    func onGameViewButtonSelected()
}

class HomeViewController: UIViewController {
    var newView: UIView?
    var delegate: HomeViewDelegate?
    var clickButtonToStart: UIButton?
    
   
    override func viewDidLoad() {
        super.viewDidLoad()
        
      
        newView = UIView()
        
        newView?.frame = CGRect(x: 0,y: 0, width: 400, height:400)
        //newView = self.view.bounds
        newView?.backgroundColor = UIColor.red
        self.view.addSubview(newView!)
        
        
      
        // Do any additional setup after loading the view.
        clickButtonToStart = UIButton()
        clickButtonToStart?.frame = CGRect(x: 100, y: 100, width: 100, height: 100)
        clickButtonToStart?.backgroundColor = UIColor.green
        clickButtonToStart?.addTarget(self, action: #selector(ButtonPress(button:)), for: .touchUpInside)
        self.view.addSubview(clickButtonToStart!)
    }

    
   @objc func ButtonPress(button: UIButton){
        if(button == clickButtonToStart){
            self.delegate?.onGameViewButtonSelected()
        }
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
