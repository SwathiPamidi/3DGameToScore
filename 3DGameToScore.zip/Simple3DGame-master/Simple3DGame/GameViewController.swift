//
//  GameViewController.swift
//  Simple3DGame
//
//  Created by Brian Advent on 16/01/2017.
//  Copyright © 2017 Brian Advent. All rights reserved.
//
// This class i pulled from github.. i will give most of the credit to Braian Adent.

import UIKit
import QuartzCore
import SceneKit

protocol GameViewControllerDelegate: class {
    func onGameViewButtonSelected()
    func endGame()
}


class GameViewController: UIViewController, SCNSceneRendererDelegate {

    
    
    weak var delegate: GameViewControllerDelegate?
    
    
    var gameView:SCNView!
    var gameScene:SCNScene!
    var cameraNode:SCNNode!
    var targetCreationTime:TimeInterval = 0
    
    var label: UILabel?

    var i = 0
    
    var button: UIButton?
    var button1: UIButton?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        label = UILabel()
        label?.frame = CGRect(x: 0, y: 20, width: 250, height: 40)
        
        label?.backgroundColor = UIColor.white
        label?.text = "Number = \(i)"
        self.view.addSubview(label!)
      
        
        initView()
        initScene()
        initCamera()
      
        self.gameView.backgroundColor = UIColor.white
        
    }
    
    func initView(){
        gameView = self.view as! SCNView
        gameView.allowsCameraControl = true
        gameView.autoenablesDefaultLighting = true
        
        gameView.delegate = self
    }
    
    func initScene (){
        gameScene = SCNScene()
        gameView.scene = gameScene
        
        gameView.isPlaying = true
        
    }
    
    func initCamera() {
        cameraNode = SCNNode()
        cameraNode.camera = SCNCamera()
        
        cameraNode.position = SCNVector3(x: 0, y:7, z: 10)
        
        gameScene.rootNode.addChildNode(cameraNode)
        
    }
    
    func createTarget() {
        //--------different shape------------
    
        let geometry:SCNGeometry = SCNTube(innerRadius: 0.5, outerRadius: 0.5, height: 1)
        
        let randomColor = arc4random_uniform(2) == 0 ? UIColor.green : UIColor.red
        
        geometry.materials.first?.diffuse.contents = randomColor
        
        let geometryNode = SCNNode(geometry: geometry)
        geometryNode.physicsBody = SCNPhysicsBody(type: .dynamic, shape: nil)
        
        if randomColor == UIColor.red {
            geometryNode.name = "enemy"
        }else{
            geometryNode.name = "friend"
        }
        
        gameScene.rootNode.addChildNode(geometryNode)
        
        
        let randomDirection:Float = arc4random_uniform(2) == 0 ? -1.0 : 1.0
        
        let force = SCNVector3(x: randomDirection, y: 15, z: 0)
        
        geometryNode.physicsBody?.applyForce(force, at: SCNVector3(x: 0.05, y: 0.05, z: 0.05), asImpulse: true)
        
        //--------different shape------------
        let geometry1:SCNGeometry = SCNSphere(radius: 0.5)
        
        let randomColor1 = arc4random_uniform(2) == 0 ? UIColor.yellow : UIColor.blue
        
        geometry1.materials.first?.diffuse.contents = randomColor1
        
        let geometryNode1 = SCNNode(geometry: geometry1)
        geometryNode1.physicsBody = SCNPhysicsBody(type: .dynamic, shape: nil)
        
        if randomColor1 == UIColor.yellow {
            geometryNode1.name = "enemy"
        }else{
            geometryNode1.name = "friend"
        }
        
        gameScene.rootNode.addChildNode(geometryNode1)
        
        
        let randomDirection1:Float = arc4random_uniform(2) == 0 ? -1.0 : 1.0
        
        let force1 = SCNVector3(x: randomDirection1, y: 15, z: 0)
        
        geometryNode1.physicsBody?.applyForce(force1, at: SCNVector3(x: 0.05, y: 0.05, z: 0.05), asImpulse: true)
        //--------different shape------------
        let geometry2:SCNGeometry = SCNPyramid(width: 1, height: 1, length: 1)
        
        let randomColor2 = arc4random_uniform(2) == 0 ? UIColor.purple : UIColor.brown
        
        geometry2.materials.first?.diffuse.contents = randomColor1
        
        let geometryNode2 = SCNNode(geometry: geometry2)
        geometryNode2.physicsBody = SCNPhysicsBody(type: .dynamic, shape: nil)
        
        if randomColor2 == UIColor.brown {
            geometryNode2.name = "enemy"
        }else{
            geometryNode2.name = "friend"
        }
        
        gameScene.rootNode.addChildNode(geometryNode2)
        
        
        let randomDirection2:Float = arc4random_uniform(2) == 0 ? -1.0 : 1.0
        
        let force2 = SCNVector3(x: randomDirection2, y: 15, z: 0)
        
        geometryNode2.physicsBody?.applyForce(force2, at: SCNVector3(x: 0.05, y: 0.05, z: 0.05), asImpulse: true)
        
    }
    
    func renderer(_ renderer: SCNSceneRenderer, updateAtTime time: TimeInterval) {
        if time > targetCreationTime {
            createTarget()
            targetCreationTime = time + 1.5
        }
        
        cleanUp()
    }
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        let touch = touches.first!
        
        let location = touch.location(in: gameView)
        
        let hitList = gameView.hitTest(location, options: nil)
        
        if let hitObject = hitList.first {
            let node = hitObject.node
            
            //based on the friend color or enemy colour we click our score is dependent
            if node.name == "friend" {
                node.removeFromParentNode()
                self.gameView.backgroundColor = UIColor.white
                i = i+1
                label?.text = "Number = \(i)"
            }else {
                node.removeFromParentNode()
                self.gameView.backgroundColor = UIColor.blue
                i = i-1
                label?.text = "Number = \(i)"
                if(i <= 0)
                {
                    print("game end")
                    gameView.isPlaying = false
                     //gameScene.removeAllParticleSystems()
                    
                    
                   //button click to replay
                    button = UIButton()
                    button?.frame = self.view.bounds
                    
                    button?.backgroundColor = UIColor.brown
                   // button?.layer.opacity = 0.5
                    button?.addTarget(self, action: #selector(ButtonPress(button:)), for: .touchUpInside)
                    self.view.addSubview(button!)
                    
                    
                    button1 = UIButton()
                    button1?.frame = CGRect(x: 50, y: 300, width: 300, height: 300)
                    
                    button1?.backgroundColor = UIColor(patternImage: UIImage(named: "play.png")!)
                    button1?.contentMode = UIViewContentMode.scaleAspectFit
                 
                    button1?.addTarget(self, action: #selector(ButtonPress(button:)), for: .touchUpInside)
                    
                    self.view.addSubview(button1!)
                    
   
                }
            }
        }
    }
    
    @objc func ButtonPress(button: UIButton){
        if(button == button){
            button.removeFromSuperview()
            button1?.removeFromSuperview()
           gameView.isPlaying = true
            i = 0
        }else if(button == button1){
            button.removeFromSuperview()
            button1?.removeFromSuperview()
            gameView.isPlaying = true
            i = 0
        }
        
    }
    
    
    func cleanUp () {
        for node in gameScene.rootNode.childNodes {
            if node.presentation.position.y < -2 {
                node.removeFromParentNode()
            }
        }
    }
    
    
    override var shouldAutorotate: Bool {
        return true
    }
    
    override var prefersStatusBarHidden: Bool {
        return false
    }
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        if UIDevice.current.userInterfaceIdiom == .phone {
            return .allButUpsideDown
        } else {
            return .all
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Release any cached data, images, etc that aren't in use.
    }

}
