//
//  ApplicationViewController.swift
//  Simple3DGame
//
//  Created by Swathi Pamidi on 6/9/18.
//  Copyright © 2018 Brian Advent. All rights reserved.
//

import UIKit

class ApplicationViewController: NSObject, GameViewControllerDelegate, HomeViewDelegate, EndViewControllerDelegate {

    
    var NavigationPath: UINavigationController
    
    var appWindow: UIWindow
    
    var HomeViewScreen: HomeViewController!
    var GameViewScreen: GameViewController!
    var EndViewScreen: EndViewController!
    
    init(appWindow: UIWindow) { // Constructor
        
        NavigationPath = UINavigationController()
        
        self.appWindow = appWindow
        
        self.HomeViewScreen = HomeViewController()
        self.GameViewScreen = GameViewController()
        self.EndViewScreen = EndViewController()
        
        super.init()
        
        self.HomeViewScreen.delegate = self as? HomeViewDelegate
        
        self.appWindow.rootViewController = self.NavigationPath
        NavigationPath.pushViewController(self.HomeViewScreen, animated: false)
        
    }
    
    func endGame(){
        self.GameViewScreen.gameView.removeFromSuperview()
        let vc = EndViewController()
        vc.modalPresentationStyle = .overCurrentContext
        vc.modalTransitionStyle = .crossDissolve
        vc.preferredContentSize = CGSize(width: 400, height: 400)
        NavigationPath.pushViewController(vc, animated: true)
    }
    
    
    func onGameViewButtonSelected(){
        
        self.showGameViewController()
    }
    
    func showGameViewController()
    {
        NavigationPath.pushViewController(self.GameViewScreen, animated: true)
    }
    
    
}
