//
//  EndViewController.swift
//  Simple3DGame
//
//  Created by Swathi Pamidi on 6/9/18.
//  Copyright © 2018 Brian Advent. All rights reserved.
//

import UIKit

protocol EndViewControllerDelegate: class {
    
}

class EndViewController: UIViewController {

    
    weak var delegate: EndViewControllerDelegate?
    
    var creditsView : UIView?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        //------- Do any additional setup after loading the view, typically from a nib.
        
        creditsView = UIView(frame: CGRect(x: 10, y: 100, width: 300, height: 300))
        // Change UIView background colour
        creditsView?.backgroundColor=UIColor.white
        // Add rounded corners to UIView
        
        // Add border to UIView
        creditsView?.layer.borderWidth=10
        // Change UIView Border Color to Red
        // creditsView?.layer.borderColor = UIColor.black.cgColor
        
        
        if(creditsView != nil)
        {
            self.view.addSubview(creditsView!)
        }
        else {
            print(Error.self)
        }
        self.view.backgroundColor = UIColor.red
    }
    
    override func viewDidLayoutSubviews() {
        
        creditsView?.frame = self.view.bounds
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
